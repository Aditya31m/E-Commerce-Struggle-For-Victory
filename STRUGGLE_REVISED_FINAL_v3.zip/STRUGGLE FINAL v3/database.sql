-- STRUGGLE / STUDIO Database Schema (for future PHP/MySQL backend)
-- Frontend currently uses LocalStorage simulation

CREATE DATABASE IF NOT EXISTS struggle_studio;
USE struggle_studio;

CREATE TABLE products (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(255) NOT NULL,
  price INT NOT NULL,
  original_price INT NULL,
  category VARCHAR(50),
  material VARCHAR(100),
  description TEXT,
  images JSON,
  colors JSON,
  sizes JSON,
  badge VARCHAR(50),
  stock INT DEFAULT 0,
  is_new TINYINT(1) DEFAULT 0,
  is_best_seller TINYINT(1) DEFAULT 0,
  is_deal TINYINT(1) DEFAULT 0,
  collection VARCHAR(50),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE orders (
  id VARCHAR(50) PRIMARY KEY,
  customer_name VARCHAR(150),
  customer_email VARCHAR(150),
  customer_phone VARCHAR(30),
  shipping_address TEXT,
  shipping_city VARCHAR(100),
  shipping_province VARCHAR(100),
  shipping_postal VARCHAR(20),
  payment_method VARCHAR(50),
  subtotal INT,
  shipping_fee INT,
  total INT,
  status VARCHAR(30) DEFAULT 'Pending',
  payment_status VARCHAR(30) DEFAULT 'Unpaid',
  shipping_status VARCHAR(30) DEFAULT 'Pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE order_items (
  id INT PRIMARY KEY AUTO_INCREMENT,
  order_id VARCHAR(50),
  product_id INT,
  product_name VARCHAR(255),
  color VARCHAR(50),
  size VARCHAR(20),
  qty INT,
  price INT,
  FOREIGN KEY (order_id) REFERENCES orders(id)
);

CREATE TABLE users (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(150),
  email VARCHAR(150) UNIQUE,
  phone VARCHAR(30),
  password_hash VARCHAR(255),
  role VARCHAR(30) DEFAULT 'customer',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE addresses (
  id INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT,
  label VARCHAR(50),
  recipient_name VARCHAR(150),
  address TEXT,
  city VARCHAR(100),
  postal_code VARCHAR(20),
  is_default TINYINT(1) DEFAULT 0,
  FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE coupons (
  id INT PRIMARY KEY AUTO_INCREMENT,
  code VARCHAR(50) UNIQUE,
  description VARCHAR(255),
  discount_type ENUM('percent','fixed','shipping'),
  discount_value INT,
  max_discount INT,
  min_purchase INT,
  valid_until DATE,
  usage_limit INT,
  used_count INT DEFAULT 0,
  status VARCHAR(20) DEFAULT 'active'
);
