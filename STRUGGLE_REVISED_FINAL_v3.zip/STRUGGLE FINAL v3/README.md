# STRUGGLE / SFV STUDIO — E-Commerce Fashion Website (Revised)

**Struggle For Victory** · Owner: **Rafli Gumilang** · IG: [@sfvclub.co](https://www.instagram.com/sfvclub.co)

Premium streetwear & essentials e-commerce (frontend, LocalStorage). Inspired by Shopee Indonesia layout patterns.

## How to Run

1. Extract the folder  
2. Open `index.html` in Chrome / Firefox / Edge  
   **or** serve locally:
   ```
   npx serve .
   python -m http.server 8080
   ```

## Revision Highlights

### Layout & Responsive
- **Sidebar collapsible di SEMUA device** — icon hamburger (tiga garis) selalu ada; klik untuk hide/show
- Di desktop: preferensi collapsed disimpan di LocalStorage
- Di mobile/tablet: sidebar slide + overlay
- **Header rapi**: search di tengah, **Wishlist · Cart · Profile** di **pojok kanan atas** — tidak rusak di device manapun
- Grid produk & spacing disesuaikan untuk HP kecil (2 kolom → tetap rapi)

### Banner
- Slider 5 slide lebih unik (Zenthral jersey, graphic tees, hoodie, dll)
- Overlay gelap + teks & CTA lebih jelas

### Footer (detail brand)
- Multi-kolom: Brand · Shop · Account · Contact
- Nomor telepon contoh: **+62 812-3456-7890**
- Link **WhatsApp**
- Link **Instagram** (klik → https://www.instagram.com/sfvclub.co) di bawah nomor WA
- Link Linktree resmi
- Tagline: *Fight for everyone*

### Katalog diperluas (20 produk)
- **Zenthral Collection** (official SFV × Zenthral):
  - Short sleeve & **Long sleeve** (Purple / Black) sebagai opsi terpisah + warna
- **Graphic tees**: Seringai, Guns N' Roses, Black Sabbath, blink-182
- **Uniqlo-inspired basics**: U Crew, AIRism Oversized Tee, Linen Shirt, Polo, Knit, Blazer, Outer, Trousers, Shorts
- Di halaman produk: opsi **Color**, **Size**, dan **Sleeve** (jika ada)

### Fitur lain
- Auth (login/register), Cart, Wishlist, Checkout, Orders, Coupons, i18n EN/ID
- Splash screen
- Demo account: **Rafli Gumilang** / **rafli123**

## Structure

```
STRUGGLE/
├── index.html
├── login.html / account-settings.html / ...
├── product.html (support sleeve option)
├── assets/
│   ├── css/style.css + responsive.css
│   ├── js/products.js (katalog lengkap) / app.js / ...
│   └── images/products/ (termasuk jersey & graphic dari upload)
```

## Notes
- Semua data di **LocalStorage** (tanpa backend)
- Siap dikembangkan ke PHP/MySQL (lihat `database.sql`)
