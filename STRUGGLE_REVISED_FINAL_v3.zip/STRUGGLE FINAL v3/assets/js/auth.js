/**
 * STRUGGLE / STUDIO - Auth & User Management
 * Multi-account support with localStorage persistence
 * Default account: Rafli Gumilang / rafli123
 */
const Auth = {
  USERS_KEY: "struggle_users",
  SESSION_KEY: "struggle_session",
  CART_PREFIX: "struggle_cart_",
  WISHLIST_PREFIX: "struggle_wishlist_",

  // Seed default user on first load
  seed() {
    const users = this.getUsers();
    if (!users.find(u => u.email === "rafli@sfv.studio" || u.name === "Rafli Gumilang")) {
      users.push({
        id: "user_rafli",
        name: "Rafli Gumilang",
        email: "rafli@sfv.studio",
        phone: "+62 812-0000-0000",
        password: "rafli123",
        avatar: null,
        role: "Client Member",
        memberSince: "2024",
        createdAt: new Date().toISOString()
      });
      this.saveUsers(users);
    }
  },

  getUsers() {
    try {
      return JSON.parse(localStorage.getItem(this.USERS_KEY)) || [];
    } catch {
      return [];
    }
  },

  saveUsers(users) {
    localStorage.setItem(this.USERS_KEY, JSON.stringify(users));
  },

  getSession() {
    try {
      return JSON.parse(localStorage.getItem(this.SESSION_KEY));
    } catch {
      return null;
    }
  },

  setSession(user) {
    if (!user) {
      localStorage.removeItem(this.SESSION_KEY);
      return;
    }
    // Don't store password in session
    const { password, ...safe } = user;
    localStorage.setItem(this.SESSION_KEY, JSON.stringify(safe));
  },

  currentUser() {
    return this.getSession();
  },

  isLoggedIn() {
    return !!this.getSession();
  },

  login(email, password) {
    this.seed();
    const users = this.getUsers();
    const user = users.find(
      u => (u.email.toLowerCase() === email.toLowerCase() || u.name.toLowerCase() === email.toLowerCase()) &&
           u.password === password
    );
    if (!user) return { ok: false, error: "invalidCredentials" };
    this.setSession(user);
    return { ok: true, user };
  },

  register({ name, email, phone, password }) {
    this.seed();
    if (!name || !email || !password) return { ok: false, error: "fillAllFields" };
    if (password.length < 6) return { ok: false, error: "minPassword" };
    const users = this.getUsers();
    if (users.find(u => u.email.toLowerCase() === email.toLowerCase())) {
      return { ok: false, error: "emailExists" };
    }
    const user = {
      id: "user_" + Date.now(),
      name: name.trim(),
      email: email.trim().toLowerCase(),
      phone: phone || "",
      password,
      avatar: null,
      role: "Client Member",
      memberSince: new Date().getFullYear().toString(),
      createdAt: new Date().toISOString()
    };
    users.push(user);
    this.saveUsers(users);
    return { ok: true, user };
  },

  logout() {
    this.setSession(null);
  },

  updateProfile(updates) {
    const session = this.getSession();
    if (!session) return { ok: false };
    const users = this.getUsers();
    const idx = users.findIndex(u => u.id === session.id);
    if (idx === -1) return { ok: false };
    const allowed = ["name", "phone", "avatar"];
    allowed.forEach(k => {
      if (updates[k] !== undefined) users[idx][k] = updates[k];
    });
    this.saveUsers(users);
    this.setSession(users[idx]);
    return { ok: true, user: users[idx] };
  },

  // Per-user cart key
  cartKey() {
    const u = this.currentUser();
    return u ? this.CART_PREFIX + u.id : "struggle_cart_guest";
  },

  wishlistKey() {
    const u = this.currentUser();
    return u ? this.WISHLIST_PREFIX + u.id : "struggle_wishlist_guest";
  },

  requireLogin(redirect = "login.html") {
    if (!this.isLoggedIn()) {
      if (typeof App !== "undefined" && App.toast) {
        App.toast(_("loginRequired"), "error");
      }
      setTimeout(() => {
        location.href = redirect + (redirect.includes("?") ? "&" : "?") + "redirect=" + encodeURIComponent(location.pathname.split("/").pop() || "index.html");
      }, 600);
      return false;
    }
    return true;
  }
};

// Compatibility shim for old User object
const User = {
  get() {
    return Auth.currentUser();
  },
  save(user) {
    Auth.setSession(user);
  },
  login(email, password) {
    return Auth.login(email, password);
  },
  logout() {
    Auth.logout();
  },
  isLoggedIn() {
    return Auth.isLoggedIn();
  }
};

// Init seed
document.addEventListener("DOMContentLoaded", () => Auth.seed());
