/**
 * STRUGGLE / STUDIO - Orders & Addresses
 */
const Orders = {
  KEY: "struggle_orders",

  get() {
    try {
      return JSON.parse(localStorage.getItem(this.KEY)) || [];
    } catch {
      return [];
    }
  },

  save(orders) {
    localStorage.setItem(this.KEY, JSON.stringify(orders));
  },

  create(orderData) {
    const orders = this.get();
    const user = Auth.currentUser();
    const order = {
      id: "SFV-" + Date.now().toString(36).toUpperCase(),
      date: new Date().toISOString(),
      status: "Pending",
      paymentStatus: "Unpaid",
      shippingStatus: "Pending",
      userId: user ? user.id : null,
      customerName: user ? user.name : orderData.customerName,
      customerEmail: user ? user.email : orderData.customerEmail,
      ...orderData
    };
    orders.unshift(order);
    this.save(orders);
    return order;
  },

  getByUser() {
    const user = Auth.currentUser();
    if (!user) return [];
    return this.get().filter(o => o.userId === user.id || o.customerEmail === user.email);
  },

  getById(id) {
    return this.get().find(o => o.id === id);
  },

  updateStatus(id, status) {
    const orders = this.get();
    const order = orders.find(o => o.id === id);
    if (order) {
      order.status = status;
      this.save(orders);
    }
  }
};

const Addresses = {
  getKey() {
    const u = Auth.currentUser();
    return u ? "struggle_addresses_" + u.id : "struggle_addresses_guest";
  },

  get() {
    try {
      return JSON.parse(localStorage.getItem(this.getKey())) || [];
    } catch {
      return [];
    }
  },

  save(list) {
    localStorage.setItem(this.getKey(), JSON.stringify(list));
  },

  add(addr) {
    const list = this.get();
    addr.id = Date.now();
    if (list.length === 0) addr.isDefault = true;
    list.push(addr);
    this.save(list);
    return list;
  },

  remove(id) {
    let list = this.get().filter(a => a.id !== id);
    if (list.length && !list.some(a => a.isDefault)) list[0].isDefault = true;
    this.save(list);
    return list;
  },

  setDefault(id) {
    const list = this.get().map(a => ({ ...a, isDefault: a.id === id }));
    this.save(list);
    return list;
  },

  getDefault() {
    return this.get().find(a => a.isDefault) || this.get()[0] || null;
  }
};
